//
//  main.c
//  test
//
//  Created by 刘昊 on 8/26/18.
//  Copyright © 2018 刘昊. All rights reserved.
//
//this is a program to generate a matrix filled with random 0 or 1
// for 0, probability is p and for 1, probability is 1-p
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define m 5
#define n 5
#define p 0.1
// this is a sub_function to transform a matrix to another according to the requirement of assignment

void transform(int x[m][n]){
    int i=0;
    int j=0;
    int flag=0;
    int Tmatrix[m][n];
    for(i=0;i<m;i++){
        flag=0;
        for(j=0;j<n;j++){
            if(x[i][j]==1){
                for(j=0;j<n;j++){
                    Tmatrix[i][j]=1;
                }
                flag=1;
            }
        }
        if(flag==0){
            for(j=0;j<n;j++)
                Tmatrix[i][j]=0;
        }
    }
    for(j=0;j<n;j++){
        flag=0;
        for(i=0;i<m;i++){
            if(x[i][j]==1){
                for(i=0;i<m;i++){
                    Tmatrix[i][j]=1;
                }
            
            }
        }
        
    }
    
    for(i=0;i<m;i++){
        for(j=0;j<n;j++){
            x[i][j]=Tmatrix[i][j];
        }
    }
}
// the main function
int main(void){
    srand( (unsigned)time(NULL));
    int i=0;
    int j=0;
    int dice=0;
    int matrix[m][n];
    for(i=0;i<m;i++){
        for(j=0;j<n;j++){
            dice=rand()%100;
            if(dice<=100*p){
                matrix[i][j]=1;
            }
            else{
                matrix[i][j]=0;
            }
        }
    }
    printf("the random matrix is:\n");
    for(i=0;i<m;i++){
        for(j=0;j<n;j++){
            printf("%d\t",matrix[i][j]);
        }
        printf("\n");
    }
    printf("\n");
    transform(matrix);
    printf("transformed matrix is:\n");
    for(i=0;i<m;i++){
        for(j=0;j<n;j++){
            printf("%d\t",matrix[i][j]);
        }
        printf("\n");
    }
    return 0;
  
}
